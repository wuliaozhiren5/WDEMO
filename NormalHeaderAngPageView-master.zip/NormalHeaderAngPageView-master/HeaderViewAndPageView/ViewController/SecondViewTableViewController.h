//
//  SecondViewTableViewController.h
//  HeaderViewAndPageView
//
//  Created by su on 16/8/8.
//  Copyright © 2016年 susu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ParentClassScrollViewController.h"
@interface SecondViewTableViewController : ParentClassScrollViewController

@end

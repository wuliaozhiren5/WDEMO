//
//  WMHomeViewController.h
//  Demo
//
//  Created by Mark on 16/7/25.
//  Copyright © 2016年 Wecan Studio. All rights reserved.
//

#import "WMStickyPageController.h"

@interface WMHomeViewController : WMStickyPageController 

@end

//
//  WMDetailViewController.h
//  StickyExample
//
//  Created by Tpphha on 2017/7/22.
//  Copyright © 2017年 Tpphha. All rights reserved.
//

#import "WMPageController.h"

@interface WMDetailViewController : WMPageController

@end

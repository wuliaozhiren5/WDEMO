//
//  WMImageViewCell.h
//  WMPageController
//
//  Created by Mark on 15/6/14.
//  Copyright (c) 2015年 yq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMImageViewCell : UICollectionViewCell
@property (nonatomic, weak) UIImageView *imageView;
@end

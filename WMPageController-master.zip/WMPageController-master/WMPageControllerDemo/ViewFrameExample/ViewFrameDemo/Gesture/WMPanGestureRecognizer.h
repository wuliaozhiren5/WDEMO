//
//  WMPanGestureRecognizer.h
//  ViewFrameDemo
//
//  Created by Mark on 2016/12/13.
//  Copyright © 2016年 Wecan Studio. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WMPanGestureRecognizer : UIPanGestureRecognizer

@end

//
//  CustomPageViewController.h
//  Storyboard
//
//  Created by Mark on 15/12/5.
//  Copyright © 2015年 Wecan Studio. All rights reserved.
//

#import "WMPageController.h"

@interface CustomPageViewController : WMPageController

@end
